library(shiny)
library(bslib)

plottab<-read.table("plottaball.txt",header=T,sep="\t",stringsAsFactors=F)

# Define UI for app that draws a histogram ----
ui <- page_sidebar(
  # App title ----
  title = "Colon Crypt Simulation (Symmetric)",
  # Sidebar panel for inputs ----
  sidebar = sidebar(
    # Input: Slider  ----
    sliderInput(
      inputId = "mutrate",
      label = "Mutation rate (per genome per generation) :",
      min = 1,
      max = 3,
      value = 1
    ),
    sliderInput(
      inputId = "numstemcells",
      label = "Number of stem cells:",
      min = 4,
      max = 16,
      step = 4,
      value = 4
    ),
    sliderInput(
      inputId = "generation",
      label = "Generation number to display:",
      min = 10,
      max = 500,
      step=10,
      value = 50
    )
  ),
  card(
    card_header("Histogram of Mutation Allele Frequencies (AF < 0.01 not included)"),
    "",
    # Output: Histogram ----
    plotOutput(outputId = "distPlot")
    
  )#,
  #card(
  #  card_header("Card2"),
  #  "",
  #  #plotOutput(outputId = "distPlot")
  #)
)

# Define server logic required to draw a histogram ----
server <- function(input, output) {
  output$distPlot <- renderPlot({
    #input$generation
    #input$mutrate
    #input$numstemcells
    tempplottab <- plottab[((plottab$mutrate==input$mutrate)&(plottab$numstemcells==input$numstemcells)&(plottab$gen2==input$generation)),]
    
    num_mutations <- length(row.names(tempplottab))
    title <- paste("Generation number = ",input$generation,"\nMutation rate per generation = ",input$mutrate,"\nNumber of stem cells in niche = ",input$numstemcells,"\nTotal mutation count = ",length(row.names(tempplottab)),sep="")
    
    h<-hist(tempplottab$AF,freq=T,breaks=seq(0,0.6,0.01),xlab="Allele Frequency",main="",xlim=c(0,0.6),ylim=c(0,100))
    abline(v=c(0.5,0.25,0.125,0.0625),lty=2,col="gray90")
    mtext(title,3,line=-2,cex=1.2)
    tempcount=h$counts[50]
    if (tempcount>100) {
      text(0.52,105,tempcount,xpd=T)
    }
  })
}

shinyApp(ui = ui, server = server)

